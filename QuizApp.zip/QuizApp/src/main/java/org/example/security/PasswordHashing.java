package org.example.security;

import org.springframework.security.crypto.bcrypt.BCrypt;

public class PasswordHashing {
    public String hashPassword(String plainTextPassword) {
        // The higher the workload factor, the more secure but slower the hashing
        int workload = 10;

        // Generate a salt
        String salt = BCrypt.gensalt(workload);

        // Hash the password with the salt
        String hashedPassword = BCrypt.hashpw(plainTextPassword, salt);

        return hashedPassword;
    }
}
