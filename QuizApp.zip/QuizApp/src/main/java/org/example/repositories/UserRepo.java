package org.example.repositories;


import org.example.entity.User;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface UserRepo extends CrudRepository<User,Long> {

    @Query(value = "select emp_id,username,role,password from user_varun",nativeQuery = true)
    List<User> fetchUsers();

    @Modifying
    @Transactional
    @Query(value = "delete from user_varun where emp_id=?",nativeQuery = true)
    void deleteUser(Long id);

}
